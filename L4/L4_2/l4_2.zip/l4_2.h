#pragma once

typedef struct
{
    int dia;
    int mes;
    int ano;
} tData;

void LerData(tData *data);
void ImprimeData(tData *data);
void ValidaData(tData *data);
void ValidaData(tData *data);